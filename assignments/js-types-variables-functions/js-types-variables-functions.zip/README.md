# JS types, variables, functions

### Setup 
1. Go into your assingment folder, create the correctly numbered assignment directory, and cd into it.
  - Ex:
  ```sh
  cd ~/TIY/assignments
  mkdir assignment-XX
  cd assignment-XX
  ```

2. Curl and unzip the assignment files
  - Ex:
  ```
  unzip 
  ```
  


###Instructions
