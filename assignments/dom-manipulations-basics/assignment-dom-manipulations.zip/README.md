#DOM Manipulations - Basics

##Setup
1 -- navigate to your `assignments` directory:
```
cd ~/TIY/assignments
```

2 -- [Download the zip file](https://github.com/TIY-Charleston-Front-End-Engineering/Course-Guide/blob/master/assignments/13-dom-manipulations-basics/assignment-13-dom-manipulations-basics.zip?raw=true)

3 -- Move the zip file to your present working directory (from `~/Downloads/assignment-13-dom-manipulations-basics.zip` to `~/TIY/assignments/`)

4 -- Unzip the file:
```
unzip assignment-dom-manipulations-basics.zip
```

5 -- Change into the directory 
```
cd assignment-XX
``` 

6 -- Complete the assignment. All of your work will be in the `main.js` file.

7 -- Submit in Newline