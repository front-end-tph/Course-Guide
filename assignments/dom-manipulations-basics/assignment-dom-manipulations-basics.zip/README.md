#DOM Manipulations - Basics

##Setup
1 -- navigate to your `assignments` directory:
```
cd ~/TIY/assignments
```

2 -- Create the project folder for the correct number
```
mkdir assignment-XX
cd assignment-XX
```

3 -- Inside your `assignment-XX` folder, download + unzip the file:
```
curl https://raw.githubusercontent.com/TIY-Charleston-Front-End-Engineering/Course-Guide/master/assignments/dom-manipulations-basics/ssignment-dom-manipulations-basics.zip > assignment-dom-manipulations-basics.zip

unzip assignment-dom-manipulations-basics.zip
```

4 -- Complete the tasks outlined in the assignment. All of your work will be in the `main.js` file.

5 -- Submit in Newline