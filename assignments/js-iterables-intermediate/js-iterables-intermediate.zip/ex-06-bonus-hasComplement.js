
/** ! Adventure Mode !
 * Ex : hasComplement() *
 *
 * Write a function called hasComplement that accepts a target number 
 * and an array of numbers
 *
 * If the sum of any two numbers in the array of numbers equals the 
 * target number , then the function should return `true`, 
 * otherwise, the function should return `false`.
 * 
*/

