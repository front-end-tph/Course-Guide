// //Create a
// 
// 
// var output = makePairs([10,20,30,40,50,60,70,80]) 
// var firstPair = output[0];
// var thirdPair = output[2];
// 
// console.assert(output.length === 4)
// console.assert(firstPair.length === 2)
// console.assert(firstPair[0] === 10)
// console.assert(firstPair[1] === 20)
// console.assert(thirdPair[0] === 50)
// console.assert(thirdPair[1] === 60)
// 
// 
