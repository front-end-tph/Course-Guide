// GO!

// TASK 1 -- Show/Hide Nav

// TASK 2 -- Select an Icon

// TASK 3 -- Move Item From List to List

// TASK 4 -- Add Guest to List

// TASK 5 -- (Adventure Mode)-- Add + Remove Item From List
